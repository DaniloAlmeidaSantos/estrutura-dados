package strategy;

public interface Imposto {
	double calculaOrcamento(double orcamento);
}
